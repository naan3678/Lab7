var serial; //holds instance of serialport
var portName = "COM4";
var outValue = 0;

function setup() { 
  //createCanvas(320, 240);
  createCanvas(600, 600);
  serial = new p5.SerialPort();
  serial.open(portName); //open your port
} 

function draw() { 
  background("#3399EE");
  fill(255);
  //text(mouseY, width/2, height/2);
  textSize(60);
  text("Press keys 0 - 9 "+"\n"+"to change brightness:", 20, 200);
  text(key, 300, 400);
}

function keyPressed(){
	if(key >= 0 && key <= 9){
    outValue = byte(key * 25);
  }
  serial.write(outValue);
}

/*function mouseDragged(){
	serial.write(mouseY);
}*/